package nqueens;

import java.io.*;
import java.util.ArrayList;

public class Board {
	
	static int boardSize;
	static Square[][] board;
	static Queen[] queensArray;
	
	//create the board (populate it with squares)
	//also populate the queensArray with Queens
	public static void createBoard(int n){
		boardSize = n;
		board = new Square[n+1][n+1];
		for(int i=1; i<=n; i++){
			for(int j=1; j<=n; j++){
				board[i][j] = new Square();
			}
		}
		queensArray = new Queen[boardSize+1];
		for(int q=1; q<=boardSize; q++){
			queensArray[q] = new Queen();
		}
	}
	
	public static void populateBoard(){
		for (int i=1; i<=boardSize; i++){
			//System.out.println("boardSize" + boardSize);
			//System.out.println("i" + i);
			queensArray[i].xpos = i;
			queensArray[i].ypos = i;
			board[i][i].hasQueen = true;
		}
	}

	public static Square[][] resolveConflicts(int n){
		//read in first line of file to get i
		//int n = 4;
		int boardloops = 500; 
		createBoard(n);
		populateBoard();
		int tries = 0;
		
		//finding conflicts and changing the position of the Queens
		while(tries<boardloops){
			for(int x=1; x<=boardSize; x++){
				for(int y=1; y<=boardSize; y++){
					if(board[x][y].hasQueen == true){
						int[] lowYpos = Square.conflict(n, board, x, y);
						int Ypos = lowYpos[0]; 
						int conflicts = lowYpos[1];
						board[x][y].hasQueen = false;
						board[x][Ypos].hasQueen = true;
						queensArray[x].ypos = Ypos;
						if(conflicts == 0){ 
							queensArray[x].hasConflicts = false; 
						}
						//CHANGE
						else{
							queensArray[x].hasConflicts = true;
						}
						break;
					}
				}
			}
			int queensCon=0;
			for(int i=1; i<=boardSize; i++){
				if(queensArray[i].hasConflicts){
					//System.out.println("Queen" + i + "has conflict");
					queensCon++;
				}	
			}
			
			if(queensCon==0){
				System.out.println("Conflicts resolved");
				break;
			}
			else 
				tries++;
		}
		return board;
	}
		
	//CHANGE
	//create the board and write it into a new file
	//board sizes are gotten from the array that is passed in created from the "nqueens.txt" file
	
	public static void makeBoard(int[] nums){
		try{
			File f = new File("nqueens_out.txt");
			FileWriter fw = new FileWriter(f);
			BufferedWriter bw = new BufferedWriter(fw);
			
			for(int cur=0; cur<nums.length; cur++){
				int n = nums[cur];
				Square[][] finboard = resolveConflicts(n);
				int[] outArray = new int[n];
					for(int y=1; y<=n; y++)
					{
						for(int x=1; x<=n; x++)
						{
							if(n<250){
								if(finboard[x][y].hasQueen == true){
									outArray[y-1] = x;
									System.out.print("q ");
									bw.write("q ");
								}
								else{
									System.out.print("x ");
									bw.write("x ");
								}
							}
							else{
								if(finboard[x][y].hasQueen == true){
									outArray[y-1] = x;	
								}
							}		
						}
						if(n<250)
						{
							System.out.println();
							bw.newLine();
						}
					}
					System.out.print("[");
					bw.write("[");
					for(int i=0; i<n-1; i++){
						System.out.print(outArray[i] + ",");
						String pr = Integer.toString(outArray[i]);
						bw.write(pr);
						bw.write(",");
					}
					System.out.print(outArray[n-1]);
					String last = Integer.toString(outArray[n-1]);
					bw.write(last);
					System.out.print("]");
					bw.write("]");
					bw.newLine();
					bw.newLine();
					
				}
				bw.close();
			}
			
			
			catch(Exception e){
				e.printStackTrace();
			}		
			
	}
		
		//CHANGE
		//read from file and put inputs into an array
		//call the function that creates the board from the array
		public static void main(String[]args){
			try{
					File f = new File("nqueens.txt");
					FileReader fr = new FileReader(f);
					BufferedReader br = new BufferedReader(fr);
					String currentLine = "start";
					ArrayList<Integer> list = new ArrayList<Integer>();
					
					while((currentLine = br.readLine()) != null){
						int currentInt = Integer.parseInt(currentLine);
					    list.add(currentInt);
					}
					br.close();

					int[] boardSizes = new int[list.size()];
					for(int i=0; i<list.size(); i++){
						boardSizes[i] = list.get(i);
					}
					makeBoard(boardSizes);
					
			}
			catch(Exception e){
				System.out.println(e.getMessage());
			}
			
		}
		
}

