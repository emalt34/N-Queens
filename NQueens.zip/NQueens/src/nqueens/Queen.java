package nqueens;

public class Queen {
	
	public int xpos;
	public int ypos;
	
	public boolean hasConflicts = true;
}
