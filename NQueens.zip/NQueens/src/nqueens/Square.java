package nqueens;

public class Square {

	public boolean hasQueen = false;
	//public boolean conflict = false;

	// make method that is called when a queen is found to determine if there is
	// another queen conflicting with it
	// if there is, count how many there are

	
	//passing in:
	//n= size of board,
	//board, 
	//xpos, and ypos which are the location of the queen
	public static int[] conflict(int n, Square[][] board, int Xpos, int Ypos) { 
		int con = 0;
		int lowcon = n;
		int lowY = Ypos;
		int Ypos1 = Ypos;
		int[] lowConInfo = new int[2]; 
		//int Ypos1 = Ypos;
		//int Xpos1 = Xpos;
		
		do{
			//queen's row (same y)
			int y = Ypos;
			for(int x=1; x<=n; x++){
				if(board[x][y].hasQueen==true && x!=Xpos){
					//System.out.println("square has conflict");
					con++;
					break;
				}
			}
			//down-right diagonal
			//start at Xpos+1 so it's not checking itself as a queen
			int x=Xpos+1;
			for(y=Ypos+1; y<=n; y++){
				if(x==n+1)
					break;
				else if(board[x][y].hasQueen==true){
					//System.out.println("square has conflict");
					con++; 
					break;
				}
				else
					x++;
			}	
			//up-left diagonal
			x=Xpos-1; 
			for(y=Ypos-1; y>=1; y--){
				if(x==0)
					break;
				else if(board[x][y].hasQueen==true){
					//System.out.println("square has conflict");
					con++; 
					break;
				}
				else
					x--;
			}
			
			//up-right diagonal
			x=Xpos+1; 
			for(y=Ypos-1; y>=1; y--){
				if(x==n+1)
					break;
				else if(board[x][y].hasQueen==true){
					//System.out.println("square has conflict");
					con++; 
					break;
				}
				else
					x++;
			}
			
			//down-left diagonal
			x=Xpos-1;
			for(y=Ypos+1; y<=n; y++){
				if(x==0)
					break;
				else if(board[x][y].hasQueen==true){
					//System.out.println("square has conflict");
					con++; 
					break;
				}
				else
					x--;
			}
			
			if (con <= lowcon) {
				lowcon = con;
				lowY = Ypos;
			}
			//CHANGE
			con = 0;
			Ypos = (Ypos + 1) % (n+1);
			if(Ypos==0)
				Ypos++;
			
		} while (Ypos != Ypos1);
		lowConInfo[0] = lowY;
		lowConInfo[1] = lowcon;
	return lowConInfo;
		
	}

	
	
}
